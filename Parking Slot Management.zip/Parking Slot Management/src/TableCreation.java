import java.sql.*;

public class TableCreation {
    private static final String URL = "jdbc:mysql://localhost:3306/parking_management";
    private static final String USER = "root";
    private static final String PASSWORD = "password"; // Update with your MySQL password

    public static void main(String[] args) {
        // Establish database connection
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Create table if not exists with additional columns
            String createTableSQL = """
                CREATE TABLE IF NOT EXISTS parking_slots (
                    slot_id INT PRIMARY KEY AUTO_INCREMENT,
                    slot_number VARCHAR(10) NOT NULL,
                    vehicle_type VARCHAR(20) NOT NULL,
                    is_occupied BOOLEAN DEFAULT FALSE,
                    vehicle_number VARCHAR(20),
                    phone_number VARCHAR(15),
                    entry_time DATETIME
                )
            """;
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createTableSQL);
                System.out.println("Table 'parking_slots' created successfully.");
            }

            // Add 50 slots (25 for 2-wheelers, 25 for 4-wheelers)
            for (int i = 1; i <= 50; i++) {
                String vehicleType = (i <= 25) ? "2 Wheeler" : "4 Wheeler";
                String slotNumber = "S" + i;

                // Prepare the insert statement with additional details
                String insertSlotSQL = "INSERT INTO parking_slots (slot_number, vehicle_type, vehicle_number, phone_number, entry_time) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement pst = conn.prepareStatement(insertSlotSQL)) {
                    pst.setString(1, slotNumber);
                    pst.setString(2, vehicleType);
                    pst.setString(3, null); // No vehicle number initially
                    pst.setString(4, null); // No phone number initially
                    pst.setTimestamp(5, null); // No entry time initially
                    pst.executeUpdate();
                }
            }
            System.out.println("50 parking slots (25 for 2-wheelers and 25 for 4-wheelers) added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
