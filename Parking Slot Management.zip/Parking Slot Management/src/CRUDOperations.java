import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

public class CRUDOperations {
    private static final String URL = "jdbc:mysql://localhost:3306/parking_management";
    private static final String USER = "root";
    private static final String PASSWORD = "password"; // Update with your MySQL password

    // Add a vehicle to a parking slot
    public static void addVehicle(int slotId, String vehicleNumber, String phoneNumber) {
        String addVehicleSQL = "UPDATE parking_slots SET vehicle_number = ?, phone_number = ?, entry_time = NOW(), is_occupied = TRUE WHERE slot_id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement(addVehicleSQL)) {

            pst.setString(1, vehicleNumber);
            pst.setString(2, phoneNumber);
            pst.setInt(3, slotId);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Vehicle added to slot " + slotId);
            } else {
                System.out.println("Slot " + slotId + " is already occupied or does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Remove a vehicle from a parking slot
    public static void removeVehicle(int slotId) {
        String removeVehicleSQL = "UPDATE parking_slots SET vehicle_number = NULL, phone_number = NULL, entry_time = NULL, is_occupied = FALSE WHERE slot_id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement(removeVehicleSQL)) {

            pst.setInt(1, slotId);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Vehicle removed from slot " + slotId);
            } else {
                System.out.println("Slot " + slotId + " is already empty or does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View all parking slots (full/empty)
    public static void viewAllSlots() {
        String viewSlotsSQL = "SELECT slot_id, slot_number, vehicle_type, is_occupied FROM parking_slots";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(viewSlotsSQL)) {

            while (rs.next()) {
                int slotId = rs.getInt("slot_id");
                String slotNumber = rs.getString("slot_number");
                String vehicleType = rs.getString("vehicle_type");
                boolean isOccupied = rs.getBoolean("is_occupied");

                System.out.println("Slot ID: " + slotId + ", Slot Number: " + slotNumber +
                        ", Vehicle Type: " + vehicleType + ", Occupied: " + (isOccupied ? "Yes" : "No"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get details of a specific parking slot by slot_id
    public static void getSlotDetails(int slotId) {
        String getSlotSQL = "SELECT slot_id, slot_number, vehicle_type, vehicle_number, phone_number, entry_time, is_occupied FROM parking_slots WHERE slot_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement(getSlotSQL)) {

            pst.setInt(1, slotId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String slotNumber = rs.getString("slot_number");
                    String vehicleType = rs.getString("vehicle_type");
                    String vehicleNumber = rs.getString("vehicle_number");
                    String phoneNumber = rs.getString("phone_number");
                    Timestamp entryTime = rs.getTimestamp("entry_time");
                    boolean isOccupied = rs.getBoolean("is_occupied");

                    System.out.println("Slot ID: " + slotId + ", Slot Number: " + slotNumber +
                            ", Vehicle Type: " + vehicleType + ", Vehicle Number: " + vehicleNumber +
                            ", Phone Number: " + phoneNumber + ", Entry Time: " + entryTime +
                            ", Occupied: " + (isOccupied ? "Yes" : "No"));
                } else {
                    System.out.println("Slot ID " + slotId + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update a parking slot with vehicle details
    public static void updateSlot(int slotId, String vehicleNumber, String phoneNumber) {
        String updateSlotSQL = "UPDATE parking_slots SET vehicle_number = ?, phone_number = ?, entry_time = NOW(), is_occupied = TRUE WHERE slot_id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement(updateSlotSQL)) {

            pst.setString(1, vehicleNumber);
            pst.setString(2, phoneNumber);
            pst.setInt(3, slotId);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Slot " + slotId + " updated with vehicle details.");
            } else {
                System.out.println("Slot " + slotId + " is already occupied or does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}