step 1: 
    -> install oracle database from online
    -> install VsCode
    -> install connector/j


step 2:
    -> open VsCode
    -> create a new Java project
        -> settings -> command pallet -> java: create new project No build tools.
    -> open JAVA PROJECT dir in VsCode -> Referenced Libraries -> select the .jar file
    -> open lib directory under your java project -> place the installed connector/j->.jar file
    -> compile it using 
        javac -cp ".;lib/mysql-connector-java-x.x.x.jar" App.java
    -> your dir structure should be:

        Project Name/
        ├── src/
        │   └── App.java
        └── lib/
            └── mysql-connector-java-x.x.x.jar

    -> run the code.


step 3: check the same using mysql terminal.
    mysql> USE abc;
        Database changed
    mysql> show tables;
        +---------------+
        | Tables_in_abc |
        +---------------+
        | students      |
        +---------------+
        1 row in set (0.05 sec)

    mysql> select * from students;
        +----+------------+------+
        | id | name       | age  |
        +----+------------+------+
        |  1 | John Doe   |   20 |
        |  2 | Jane Smith |   22 |
        |  3 | John Doe   |   20 |
        |  4 | Jane Smith |   22 |
        +----+------------+------+
        4 rows in set (0.00 sec)


step 4: DROP THE Table AND Database
    mysql> drop table students;
    Query OK, 0 rows affected (0.04 sec)

    mysql> select * from students;
    ERROR 1146 (42S02): Table 'abc.students' doesn't exist
    mysql> drop database abc;
    Query OK, 0 rows affected (0.04 sec)

    mysql> show databases;
    +--------------------+
    | Database           |
    +--------------------+
    | information_schema |
    | mysql              |
    | performance_schema |
    | sys                |
    +--------------------+
    4 rows in set (0.00 sec)

